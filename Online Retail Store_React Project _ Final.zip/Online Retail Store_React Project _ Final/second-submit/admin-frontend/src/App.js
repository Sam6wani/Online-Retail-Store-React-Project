import React, { useState } from "react";
import { Box, Heading, Flex, Button } from "@chakra-ui/react";
import Home from "./components/Home/Home";
import ProductList from "./components/ProductList/ProductList";
import ReviewList from "./components/ReviewList/ReviewList";
import { MdProductionQuantityLimits, MdOutlineAnalytics, MdOutlineReviews } from "react-icons/md"
const App = () => {
  const [selectedPage, setSelectedPage] = useState("home");

  const renderContent = () => {
    switch (selectedPage) {
      case "products":
        return <ProductList />;
      case "reviews":
        return <ReviewList />;
      case "home":
      default:
        return <Home />;
    }
  };

  return (
    <Box backgroundColor="">
      <Heading
        as="h1"
        p={5}
        bgGradient="linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(23,23,25,1) 35%, rgba(0,212,255,1) 100%);"
        color="white"
        textAlign="start"
        position="fixed"
        top={0}
        width="100%"
        zIndex={1}
      >
        Soil Admin Dashboard
      </Heading>
      <Flex >
        <Box
          as="nav"
          p={5}
          bg="gray.100"
          position="fixed"
          top="72px"
          left={0}
          height="calc(100vh - 72px)"
          minWidth="200px"
          maxWidth="200px"
          flexShrink={0}
          overflowY="auto"
          backgroundColor="#000000"
        >
          <Flex direction="column" align="flex-start" >
            <Button onClick={() => setSelectedPage("home")}
              mb={4} width="100%"
              leftIcon={<MdOutlineAnalytics />}
              colorScheme='blackAlpha'
            >
              Analytics
            </Button>
            <Button
              onClick={() => setSelectedPage("products")}
              mb={4}
              width="100%"
              leftIcon={<MdProductionQuantityLimits />}
              colorScheme='blackAlpha'
            >
              Products
            </Button>
            <Button
              onClick={() => setSelectedPage("reviews")}
              mb={4}
              width="100%"
              leftIcon={<MdOutlineReviews />}
              colorScheme='blackAlpha'
            >
              Reviews
            </Button>
          </Flex>
        </Box>
        <Box
          as="main"
          p={5}
          flexGrow={1}
          ml="200px"
          mt="72px"
          overflow="auto"
          height="calc(100vh - 72px)"
        >
          {renderContent()}
        </Box>
      </Flex>
    </Box>
  );
};

export default App;
